var express = require('express')
var app = express()
var { check, sanitizeBody, sanitizeParam, validationResult } = require('express-validator');
var appendAnothersField=(a,b,c,d)=>{
	// append field if has own property
	for(var i in c){
		if(a.body.hasOwnProperty(c[i])) b[c[i]]=a.body[c[i]]
	}
	// append field for createdby/modifiedby
	if(d==0) b['createdby']=a.user?a.user.username:'system'
	else b['modifiedby']=a.user?a.user.username:'system'
	return b
}
var endpointName = "Production House";

/********** Get Data ***********/
app.get('/', (req, res, next)=> {
	req.getConnection((error, conn)=> {
		// statement SQL
		var strSQL = "select id,name from tproduction_house"
		// exec statement SQL
		conn.query(strSQL,function(err, rows, fields) {
			if(err) return res.json({status:false, data:[], message:err})
			return res.json({status:true, data:rows, message:(rows.length>0?"":"Record Not Found!")})
		})
	})
})

/********** Get Data based on param ID ***********/
app.get('/:id', [
		sanitizeParam('id').escape().trim().toInt()
	], (req, res, next)=>{
	req.getConnection((error, conn)=> {
		// statement SQL
		var strSQL = "select id,name from tproduction_house where id = ?"
		// exec statement SQL
		conn.query(strSQL, [req.params.id], (err, rows, fields)=> {
			if(err) return res.json({status:false, data:[], message:err})
			return res.json({status:true, data:rows, message:(rows.length>0?"":"Record Not Found!")})			
		})
	})
})

/********** Post/Insert Data ***********/
app.post('/', [
		check('name', `${endpointName} Name is required`).not().isEmpty(),
		sanitizeBody('name').escape().trim()
	], (req, res, next)=>{
	// check validate entry 
	var errors = validationResult(req)	
	// if error, show response erro and automatic stop in this step
	if(errors.errors.length>0) return res.json({status:false, data:[], message:errors.errors})
	// re-struct data for Models (ORM)
	var _datas = {
		name: req.body.name
	}
	// append anothers filed based on req.body
	var datas = appendAnothersField(req, _datas, [], 0)
	// check already exists or not
	req.getConnection((error, conn)=> {
		conn.query('SELECT name FROM tproduction_house WHERE name = ?', [datas.movie], (err, rows, fields)=> {
			// if error, show response erro and automatic stop in this step
			if(err) return res.json({status:false, data:[], message:('Error Find:'+err)})
			// if data already exists or same name
			if(rows.length>0) return res.json({status:false, data:[], message:`${endpointName} Name [${datas.name}] already exists`})
			// insert data
			conn.query('INSERT INTO tproduction_house SET ?', datas, (err, result)=> {
				if(err) return res.json({status:false, data:[], message:err})
				_datas.id = result.insertId;
				return res.json({status:true, data:_datas, message:err})
			})			
		})
	})
})

/********** Put/Update Data ***********/
app.put('/:id', [
		check('name', `${endpointName} Name is required`).not().isEmpty(),
		sanitizeBody('name').escape().trim()
	], (req, res, next)=>{
	// check has own props or empty
	var errors = validationResult(req)
	// if error, show response erro and automatic stop in this step
	if(errors.errors.length>0) return res.json({status:false, data:[], message:errors.errors})
	// re-struct data for Models (ORM)
	var _datas = {
		name: req.body.name
	}
	// append anothers filed based on req.body
	var datas = appendAnothersField(req, _datas, [], 1)
	// check already exists or not
	req.getConnection((error, conn)=> {
		conn.query('SELECT id FROM tproduction_house WHERE id = ?', [req.params.id], (err, rows, fields)=> {
			// if error, show response erro and automatic stop in this step
			if(err) return res.json({status:false, data:[], message:('Error Find:'+err)})
			if(rows.length>0){
				// update if exists
				conn.query('UPDATE tproduction_house SET ? WHERE id = ' + req.params.id, datas, (err, result)=> {
					// if error, show response erro and automatic stop in this step
					if(err) return res.json({status:false, data:[], message:err})
					// set data param id in data response
					datas.id = req.params.id;
					return res.json({status:true, data:datas, message:"Data Saved Successfully"})
				})
			}else{
				// if not exists
				return res.json({status:false, data:[], message:"Data was not Found!. Please using method POST for insert this data"})
			}			
		})
	})
})

/********** Delete Data ***********/
app.delete('/:id', [
		sanitizeParam('id').escape().trim().toInt()
	], (req, res, next)=> {
	// re-struct data for Models (ORM)
	var datas= {id : req.params.id}
	req.getConnection((error, conn)=> {
		// if error, show response erro and automatic stop in this step
		if (error) return res.json({status:false, data:[], message:error})
		// get data before delete
		conn.query('SELECT id FROM tproduction_house WHERE id = ?', [datas.id], (err, rows, fields)=> {
			// if error, show response erro and automatic stop in this step
			if (err) return res.json({status:false, data:[], message:err})
			// if data not found
			if(rows.length==0) return res.json({status:false, data:datas, message:"Data Not Found!"})
			
			// if there are data in table move, reject proccess delete
			conn.query('SELECT productionHouseId FROM tmovie WHERE productionHouseId = ?', [datas.id], (err, xrows, fields)=> {
				if(xrows.length>0) return res.json({status:false, data:datas, message:"Data Production was exists on Movie"})
				// exec statement delete
				conn.query('DELETE FROM tproduction_house WHERE id = ?', [datas.id], (err, result)=> {
					// if error, show response erro and automatic stop in this step
					if (err) return res.json({status:false, data:[], message:err})
					// if not error, show response data
					return res.json({status:true, data:rows, message:"Data Delete Successfully"})
				})
			})
		})
	})
})

module.exports = app