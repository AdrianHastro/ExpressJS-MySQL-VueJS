const express = require('express')
const app = express()

var data = [
	{ endpoint: "/", method:"get", page: "Test CRUD HACKTIV8" }
]
app.get('/', (req, res) => {
	res.json({status:true, data:data, message:"WebService API is Work!"})
})

module.exports = app