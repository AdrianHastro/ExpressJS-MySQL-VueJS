//npm modules
const express = require('express')
const uuid = require('uuid/v4')
const session = require('express-session')
const flash = require('express-flash')
const FileStore = require('session-file-store')(session)
const bodyParser = require('body-parser')
const cookieParser = require('cookie-parser')
const methodOverride = require('method-override')
const mysql = require('mysql2')
const mysqlPromise = require('mysql2/promise')
const myConnection  = require('express-myconnection')
const favicon = require('serve-favicon')
const logger = require('morgan')
const passport = require('passport')
const path = require('path')

// defined config
const env = process.env.NODE_ENV || 'development'
const config = require('./config/app')[env]

// import module
const index = require('./routes/index')
const movies = require('./routes/movies')
const products = require('./routes/products')

// set app using express (using use for support sub-router and middleware)
const app = express()
app.set('config',config)
// set body parser (accepted response body JSON, url encode, automatic parsing cookie)
// uncomment after placing your favicon in /public
// app.use(favicon(path.join(__dirname, 'public', 'favicon.ico')))
app.use(logger(env))
app.use(bodyParser.json({ limit:'1000mb', extended: true }))
app.use(bodyParser.urlencoded({ limit:'1000mb', extended: true }))
// create session in this app
app.use(session({
  genid: (req) => { return uuid() },
  // store: new FileStore(),
  secret: config.app.key,
  resave: true,
  saveUninitialized: true,
  cookie: { maxAge:null, httpOnly:false }
}))
app.use(flash())
// app.use(expressValidator()); // was invalid method in middleware
app.use(cookieParser())

// app.use(require('less-middleware')(path.join(__dirname, 'public')))
app.use(express.static(path.join(__dirname, 'public')))
// This module let us use HTTP verbs such as PUT or DELETE (using custom logic to override method)
app.use(methodOverride((req, res)=> {
  if (req.body && typeof req.body === 'object' && '_method' in req.body) {
    var method = req.body._method
    delete req.body._method
    return method
  }
}))
// allow CROS-Domain
app.use((req, res, next)=> {
  res.header("Access-Control-Allow-Credentials", true)
  res.header("Access-Control-Allow-Origin", req.header('origin'))
  res.header('Access-Control-Allow-Methods', 'GET,POST,PUT,PATCH,DELETE')
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept, X-Auth-Sess, X-Auth-Key, accessToken, usertoken, X-App-Log, X-App-Endpoint, X-App-Name, X-App-Category, X-App-Module, X-App-Action")
  next()
})

// set pool MySQL
const dbconn = {
	host:	config.db.host,
  port: config.db.port, 
  user: config.db.user,
	password: config.db.password,
	database: config.db.name
}
app.use(myConnection(mysql, dbconn, 'pool'))
// app.use(myConnection(mysqlPromise, dbconn, 'pool'))

// import config passport
// require('./config/passport_local')(passport, config, mysql, dbconn)
// initiate passport in session 
// app.use(passport.initialize())
// app.use(passport.session())

// flush for consum from anothers referer
app.use(flash())
// include routes endpoints 
app.use('/', index)
app.use('/movies', movies)
app.use('/products', products)

// liste running server
app.listen(config.app.port, config.app.host, config.app.protocol,  () => {
  console.log(`Server running at ${config.app.protocol}://${config.app.host}:${config.app.port}/`)
});