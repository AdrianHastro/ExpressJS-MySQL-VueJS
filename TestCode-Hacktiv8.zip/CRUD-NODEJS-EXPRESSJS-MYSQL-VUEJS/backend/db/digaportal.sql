CREATE database `crud_hackit8`;
use `crud_hackit8`;

CREATE OR REPLACE TABLE `tmovie` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `movie` varchar(255) NOT NULL,
  `genre` varchar(255) NOT NULL,
  `productionHouseId` int(10) unsigned NOT NULL,
  `createdby` varchar(80) NOT NULL,
  `createddate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modifiedby` varchar(80) DEFAULT NULL,
  `modifieddate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  CONSTRAINT `prodH_id_foreign` FOREIGN KEY (`productionHouseId`) REFERENCES `tproduction_house` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE OR REPLACE TABLE `tproduction_house` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `createdby` varchar(80) NOT NULL,
  `createddate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modifiedby` varchar(80) DEFAULT NULL,
  `modifieddate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;