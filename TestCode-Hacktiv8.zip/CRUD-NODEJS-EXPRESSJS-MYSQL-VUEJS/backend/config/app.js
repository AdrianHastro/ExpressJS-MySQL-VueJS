const fs = require('fs')
const path = require('path')
const basicAuth = require('basic-auth')
const decCert = (data) =>{
    return fs.readFileSync(path.join(__dirname, '..', 'cert')+'\\'+data, 'utf-8')
}

module.exports = {
    development: {
        app: {
            name: 'CRUD HACKIT8',
            icon: 'favicon.ico',
            key: 'tes123',
            protocol: 'http',
            host: '127.0.0.1',
            port: 1313,
            alias: ''
        },
        db: {
            type: 'mysql',
            host: '127.0.0.1',
            port: 3306,
            user: 'root',
            password: '',
            name: 'crud_hackit8'
        },
        passport: {
            local: {
                usernameField : 'username',
                passwordField : 'password'
            },
            samlIdp: {
                entryPoint: '',
                logoutUrl: '',
                issuer: '',
                callbackUrl: '',
                host: '',
                path: '',
                cert: '',
                signatureAlgorithm: 'sha256',
                identifierFormat: process.env.IDF || null
            },
            ldap: {
                server: {
                    url: 'ldap://localhost:389',
                    bindDN: 'cn=non-person,ou=system,dc=corp,dc=corporate,dc=com',
                    bindCredentials: 'secret',
                    searchBase: 'ou=passport-ldapauth,dc=corp,dc=corporate,dc=com',
                    searchFilter: '(uid={{username}})'
                },
            }
        }
    },
    test: {
        app: {
            name: 'CRUD HACKIT8',
            icon: 'favicon.ico',
            key: 'tes123',
            protocol: 'http',
            host: '127.0.0.1',
            port: 1301,
            alias: ''
        },
        db: {
            type: 'mysql',
            host: '127.0.0.1',
            port: 3306,
            user: 'root',
            password: '',
            name: 'crud_hackit8'
        },
        passport: {
            local: {
                usernameField : 'username',
                passwordField : 'password'
            },
            samlIdp: {
                entryPoint: '',
                logoutUrl: '',
                issuer: '',
                callbackUrl: '',
                host: '',
                path: '',
                cert: '',
                signatureAlgorithm: 'sha256',
                identifierFormat: process.env.IDF || null
            },
            ldap: {
                server: {
                    url: 'ldap://localhost:389',
                    bindDN: 'cn=non-person,ou=system,dc=corp,dc=corporate,dc=com',
                    bindCredentials: 'secret',
                    searchBase: 'ou=passport-ldapauth,dc=corp,dc=corporate,dc=com',
                    searchFilter: '(uid={{username}})'
                },
            }
        }
    },
    production: {
        app: {
            name: 'CRUD HACKIT8',
            icon: 'favicon.ico',
            key: 'tes123',
            protocol: 'http',
            host: '127.0.0.1',
            port: 1301,
            alias: ''
        },
        db: {
            type: 'mysql',
            host: '127.0.0.1',
            port: 3306,
            user: 'root',
            password: '',
            name: 'crud_hackit8'
        },
        passport: {
            local: {
                usernameField : 'username',
                passwordField : 'password'
            },
            samlIdp: {
                entryPoint: '',
                logoutUrl: '',
                issuer: '',
                callbackUrl: '',
                host: '',
                path: '',
                cert: '',
                signatureAlgorithm: 'sha256',
                identifierFormat: process.env.IDF || null
            },
            ldap: {
                server: {
                    url: 'ldap://localhost:389',
                    bindDN: 'cn=non-person,ou=system,dc=corp,dc=corporate,dc=com',
                    bindCredentials: 'secret',
                    searchBase: 'ou=passport-ldapauth,dc=corp,dc=corporate,dc=com',
                    searchFilter: '(uid={{username}})'
                },
            }
        }
    }
};