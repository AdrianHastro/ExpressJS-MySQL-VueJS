module.exports = {
  NODE_ENV: '"production"',
  ALIAS_FE: '"/frontend-hacktiv8"',
  ALIAS_BE: '"/backend-hacktiv8"',
  PORTAL_BE: '"https://x.x.com:8443/backend-hacktiv8"'
}