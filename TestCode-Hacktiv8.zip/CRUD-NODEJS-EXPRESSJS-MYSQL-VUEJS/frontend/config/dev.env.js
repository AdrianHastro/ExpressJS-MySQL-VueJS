var merge = require('webpack-merge')
var prodEnv = require('./prod.env')

module.exports = merge(prodEnv, {
  NODE_ENV: '"development"',
  ALIAS_FE: '"/"',
  ALIAS_BE: '"/frontend-hacktiv8"',
  PORTAL_BE: '"http://localhost:1313"'
})
