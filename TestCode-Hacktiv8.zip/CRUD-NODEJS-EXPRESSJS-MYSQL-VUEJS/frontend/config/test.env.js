var merge = require('webpack-merge')
var devEnv = require('./dev.env')

module.exports = merge(devEnv, {
  NODE_ENV: '"testing"',
  ALIAS_FE: '"/frontend-hacktiv8"',
  ALIAS_BE: '"/backend-hacktiv8"',
  PORTAL_BE: '"https://x.x.com:8443/backend-hacktiv8"'
})
