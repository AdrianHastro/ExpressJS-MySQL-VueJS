export const movies = state => state.movies.movies
export const products = state => state.products.products