import services from '../api/services'

const _products = JSON.parse(localStorage.getItem('products'));
const state = {
    products: _products ? _products : []
}

const actions={
    getProducts({ dispatch, commit }, { msg }) {
        commit('getProducts');
        services.products.getAll().then(
            data => commit('productSuccess', data),
            error => {
                msg.e(error,'Error Data Products!')
                commit('productFailure')
            }
        )
    },
    ProductsAdd({ dispatch, commit }, {dataparam,msg}){
        services.products.postData(dataparam).then(
            data => {
                msg.s('Insert Success','Data Products!')
                commit('insertProducts', data)
            },
            error => {
                msg.e(error,'Insert Error!')
                commit('productFailure')
            }
        )
    },
    ProductsEdit({ dispatch, commit }, {dataparam,msg}){
        services.products.putData(dataparam).then(
            data => {
                msg.s('Update Success','Data Products!')
                commit('updateProducts', data)
            },
            error => {
                msg.e(error,'Update Error!')
                commit('productFailure')
            }
        )
    },
    ProductsDelete({ dispatch, commit }, {dataparam,msg}){
        services.products.deleteData(dataparam).then(
            data => {
                msg.s('Delete Success','Data Products!')
                commit('deleteProducts', data)
            },
            error => {
                msg.e(error,'Delete Error!')
                commit('productFailure')
            }
        )
    }
}

const mutations = {
    getProducts(state) {
        state.status = { getData: true };
    },
    productSuccess(state, products) {
        state.products = products;
        localStorage.setItem('products',JSON.stringify(state.products))
    },
    productFailure(state) {
        state.products = state.products;
    },
    insertProducts(state, products) {
        state.products = state.products.concat(products)
        localStorage.setItem('products',JSON.stringify(state.products))
    },
    updateProducts(state, products) {
        var newArr = _products.map(a => {
            return Number(a.id) === Number(products.id) ? {name:products.name} : a;
        })
        state.products = newArr
        localStorage.setItem('products',JSON.stringify(state.products))
    },
    deleteProducts(state, products) {
        var newArr = _products.filter(a => Number(a.idproduct) !== Number(products[0].idproduct))
        state.products = newArr
        localStorage.setItem('products',JSON.stringify(state.products))
    }
}

export default {
  state,
  actions,
  mutations
}