import services from '../api/services'
var nd = new Date()

const _movies = JSON.parse(localStorage.getItem('movies'));
const state = {
  movies: _movies ? _movies : []
}

const actions={
    getGroupMovie({ dispatch, commit }, {idx}) {
        return services.movies.getGroup(idx).then(data=>data, error=>[])
    },
    getMovies({ dispatch, commit }, { msg }) {
        commit('getMovies');
        services.movies.getAll().then(
            data => commit('movieSuccess', data),
            error => {
                msg.e(error,'Error Data Movie!')
                commit('movieFailure')
            }
        )
    },
    MoviesAdd({ dispatch, commit }, {dataparam,msg}){
        services.movies.postData(dataparam).then(
            data => {
                msg.s('Insert Success','Data Movie!')
                commit('insertMovies', data)
            },
            error => {
                msg.e(error,'Insert Error!')
                commit('movieFailure')
            }
        )
    },
    MoviesEdit({ dispatch, commit }, {dataparam,msg}){
        services.movies.putData(dataparam).then(
            data => {
                msg.s('Update Success','Data Movie!')
                commit('updateMovies', data)
            },
            error => {
                msg.e(error,'Update Error!')
                commit('movieFailure')
            }
        )
    },
    MoviesDelete({ dispatch, commit }, {dataparam,msg}){
        services.movies.deleteData(dataparam).then(
            data => {
                msg.s('Delete Success','Data Movie!')
                commit('deleteMovies', data)
            },
            error => {
                msg.e(error,'Delete Error!')
                commit('movieFailure')
            }
        )
    }
}

const mutations = {
    getMovies(state) {
        state.status = { getData: true };
    },
    movieSuccess(state, movies) {
        state.movies = movies;
        localStorage.setItem('movies',JSON.stringify(state.movies))
    },
    movieFailure(state) {
        state.movies = state.movies;
    },
    insertMovies(state, movies) {
        let xname = localStorage.getItem('products')
        movies.name = 
        state.movies = state.movies.concat(movies)
        localStorage.setItem('movies',JSON.stringify(state.movies))
    },
    updateMovies(state, movies) {
        var newArr = _movies.map(a => {
            return Number(a.id) === Number(movies.id) ? 
            {   id:movies.id, 
                movie:movies.movie, 
                idproduct:movies.idproduct, 
                name:movies.name
            } : a;
        })
        state.movies = newArr
        localStorage.setItem('movies',JSON.stringify(state.movies))
    },
    deleteMovies(state, movies) {
        var newArr = _movies.filter(a => Number(a.idmovie) !== Number(movies[0].idmovie) || a.moviename==movies[0].moviename)
        state.movies = newArr
        localStorage.setItem('movies',JSON.stringify(state.movies))
    }
}

export default {
  state,
  actions,
  mutations
}