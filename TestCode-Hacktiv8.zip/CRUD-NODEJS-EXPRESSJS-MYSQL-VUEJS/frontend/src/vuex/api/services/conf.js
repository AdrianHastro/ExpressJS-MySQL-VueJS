export default {
  urlbe: process.env.NODE_ENV=="development" ? process.env.PORTAL_BE : location.protocol+'//'+location.hostname+':'+location.port+process.env.ALIAS_BE
}