import axios from 'axios'
import conf from './conf'
const urlbe = conf.urlbe+'/products'

export default {
  getAll() {
    return axios.get(urlbe, {withCredentials:true})
      .then((response) => {
        if(typeof response.data=="string" || response.data.status==false){
          return Promise.reject(response.data.message)
        }else{
          return Promise.resolve(response.data.data)
        }
      }).catch((error) => Promise.reject(error))
  },
  postData (request = {}) {
    return axios.post(urlbe, request, {withCredentials:true})
      .then((response) => {
        if(typeof response.data=="string" || response.data.status==false){
          return Promise.reject(response.data.message)
        }else{
          return Promise.resolve(response.data.data)
        }
      }).catch((error) => Promise.reject(error))
  },
  putData (request = {}) {
    return axios.put(urlbe+'/'+request.idx, request, {withCredentials:true})
      .then((response) => {
        if(typeof response.data=="string" || response.data.status==false){
          return Promise.reject(response.data.message)
        }else{
          return Promise.resolve(response.data.data)
        }
      }).catch((error) => Promise.reject(error))
  },
  deleteData (request = {}) {
    return axios.delete(urlbe+'/'+request.idx, {withCredentials:true})
      .then((response) => {
        if(typeof response.data=="string" || response.data.status==false){
          return Promise.reject(response.data.message)
        }else{
          return Promise.resolve(response.data.data)
        }
      }).catch((error) => Promise.reject(error))
  }
}