import movies from './movies'
import products from './products'

export default {
  movies,
  products
}
