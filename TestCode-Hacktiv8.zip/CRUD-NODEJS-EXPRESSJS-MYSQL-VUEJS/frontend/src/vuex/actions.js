import * as types from './mutation-types'
import { services } from './api'

export const fetchMovies = ({ commit }) => {
  return services.movies.getAll().then((response) => commit(types.FETCH_MOVIES, response.data)).catch((error) => console.error(error))
}
export const fetchProducts = ({ commit }) => {
  return services.products.getAll().then((response) => commit(types.FETCH_PRODUCTS, response.data)).catch((error) => console.error(error))
}
