<template>

  <div class="small-box" :class="bgColor">
    <div class="inner">
      <h3>{{title}}</h3>

      <p>{{description}}</p>
    </div>
    <div class="icon">
      <i class="ion" :class="icon"></i>
    </div>
    <!-- <div class="dropdown"> -->
      <a href="javascript:void(0)" class="small-box-footer" :class="data?'dropdown-toggle':null" :data-toggle="data?'dropdown':null" @click="moreEvent">{{moreText}} <i class="fa fa-arrow-circle-right"></i></a>
      <ul v-if="data" class="dropdown-menu pull-right dropdown-menu-right" role="menu">
        <li class="dropdown-submenu" v-show="data.staging">
          <a tabindex="-1" href="javascript:void(0)">Staging Version <i class="fa fa-arrow-circle-down"></i></a>
          <ul class="xsmall dropdown-toggle">
            <li><a tabindex="-1" target="_blank" :href="data.staging.mobile.uri">Mobile: {{data.staging.mobile.package}}</a></li>
            <li><a tabindex="-1" target="_blank" :href="data.staging.web.uri">Web: {{data.staging.web.uri}}</a></li>
          </ul>
        </li>        
        <li class="divider" v-show="data.release"></li>
        <li class="dropdown-submenu" v-show="data.release">
          <a tabindex="-1" href="javascript:void(0)">Release Version <i class="fa fa-arrow-circle-down"></i></a>
          <ul class="xsmall dropdown-toggle">
            <li><a tabindex="-1" target="_blank" :href="data.release.mobile.uri">Mobile: {{data.release.mobile.package}}</a></li>
            <li><a tabindex="-1" target="_blank" :href="data.release.web.uri">Web: {{data.release.web.uri}}</a></li>
          </ul>
        </li>
      </ul>
    <!-- </div> -->
  </div>
</template>

<script>
export default {
  name: 'SmallBox',
  props: ['color', 'icon', 'title', 'description', 'moreText', 'moreAction', 'data'],
  computed: {
    bgColor () {
      return `bg-${this.color}`
    }
  },
  methods: {
    moreEvent () {
      this.$emit('more-click')
    }
  }
}
</script>
<style scoped>
.xsmall{
  font-size: 85%;
  padding-right: 20px;
}
</style>