<template>
  <div :class="this['xclass']">
    <slot></slot>
  </div>
</template>

<script>
export default {
  name: 'column',
  props: {
    'xclass': {
      type: String,
      default: ''
    }
  },
  created () {

  }
}
</script>
