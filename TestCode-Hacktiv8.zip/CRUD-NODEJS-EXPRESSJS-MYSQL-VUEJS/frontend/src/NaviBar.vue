<template>
  <header class="main-header">
    <!-- Logo -->
    <a href="javascript:void(0)" class="logo brand-link navbar-danger">
      <img src="static/img/icon.png" alt="Diga Portal" class="brand-image img-circle elevation-3" style="opacity: .8; height:32px;">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <!-- <span class="logo-mini"><b>D</b>P</span> -->
      <!-- logo for regular state and mobile devices -->
      <!-- <span class="logo-lg"><b>Diga</b>Portal</span> -->
      <span class="brand-text font-weight-light text-white">Hacktiv8</span>
    </a>

    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
      <!-- Sidebar toggle button-->
      <a href="javascript:void(0)" class="sidebar-toggle" data-toggle="push-menu" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>
      <!-- Navbar Right Menu -->
      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
          <!-- User Account: style can be found in dropdown.less -->
          <li class="dropdown user user-menu">
            <a href="javascript:void(0)" class="dropdown-toggle" data-toggle="dropdown">
              <img src="~admin-lte/dist/img/avatar5.png" class="user-image" alt="User Image">
              <span class="hidden-xs">Adrian Hastro Pagade</span>
            </a>
            <ul class="dropdown-menu">
              <!-- User image -->
              <li class="user-header">
                <img src="~admin-lte/dist/img/avatar5.png" class="img-circle" alt="User Image">
                <p>
                  Adrian Hastro Pagade <br/> FullStack Engineer
                  <small>JavaScript Developer</small>
                </p>
              </li>
              <!-- Menu Footer-->
              <li class="user-footer">
                <div class="pull-left">
                  <a href="javascript:void(0)" class="btn btn-default btn-flat">Profile</a>
                </div>
                <div class="pull-right">
                  <a href="javascript:void(0)" class="btn btn-default btn-flat">Sign out</a>
                </div>
              </li>
            </ul>
          </li>
        </ul>
      </div>
    </nav>
    <vue-toastr ref="mytoast"></vue-toastr>
  </header>
</template>

<script>
import { mapGetters } from 'vuex'
import VueToastr from 'vue-toastr'

export default {
  name: 'va-navibar',
  components:{
    'vue-toastr': VueToastr
  }
}

</script>
