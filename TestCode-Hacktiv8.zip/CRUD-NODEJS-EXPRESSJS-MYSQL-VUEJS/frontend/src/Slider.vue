<template>
  <aside id="slider" class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="~admin-lte/dist/img/avatar5.png" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <p>[A H P]</p>
          <a href="javascript:void(0)"><i class="fa fa-circle" style="color:green"></i> Online</a>
        </div>
      </div>
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul data-widget="tree" class="sidebar-menu">
        <va-slide-item
          v-for="(item,index) in menus"
          :data="item"
          :key="index"
          :type="item.type"
          :isHeader="item.isHeader"
          :icon="item.icon"
          :name="item.name"
          :badge="item.badge"
          :items="item.items"
          :router="item.router"
          :link="item.link"
        >
        </va-slide-item>
      </ul>
    </section>
  </aside>
</template>

<script>
import { mapGetters } from 'vuex'
import VASlideItem from './components/VASlideItem'

export default {
  name: 'va-slider',
  data:() => ({
    menus: [
        {"type":"item","icon":"fa fa-dashboard","name":"Dashboard","router":{"name":"Dashboard"}},
        {"type":"item","isHeader":true,"name":"CRUD MENUS"},
        {"type":"item","icon":"fa fa-unlock-alt","name":"Movies","badge":{"type":"String"},"router":{"name":"Movies"}},
        {"type":"item","icon":"fa fa-cogs","name":"Products","badge":{"type":"String"},"router":{"name":"Products"}}
    ]
  }),
  props: {
    slideMenuItems: {
      type: Array,
      default: []
    }
  },
  components: {
    'va-slide-item': VASlideItem
  }
}
</script>
