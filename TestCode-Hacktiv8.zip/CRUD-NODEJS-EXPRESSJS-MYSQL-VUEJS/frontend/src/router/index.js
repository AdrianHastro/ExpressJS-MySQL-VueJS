import Vue from 'vue'
import Router from 'vue-router'

import Dashboard from 'pages/dashboard.vue'
import MoviesPage from 'pages/movies.vue'
import ProductsPage from 'pages/products.vue'

Vue.use(Router)

const router = new Router({
  mode: 'history',
  base: process.env.ALIAS_FE,
  routes: [
    { path: '*', redirect: '/' },
    {
      path: '/',
      name: 'Home',
      component: Dashboard,
      meta: {
        auth: true,
        title: 'Dashboard',
      }
    },
    {
      path: '/dashboard',
      name: 'Dashboard',
      component: Dashboard,
      meta: {
        auth: false,
        title: 'Dashboard',
      } 
    },
    {
      path: '/movies',
      name: 'Movies',
      component: MoviesPage,
      meta: {
        auth: false,
        title: 'Movies',
      } 
    },
    {
      path: '/products',
      name: 'Products',
      component: ProductsPage,
      meta: {
        auth: false,
        title: 'Production House',
      } 
    }
  ],
  linkActiveClass: 'active'
})

router.beforeEach((to, from, next) => {
  // const publicPages = ['/login'];
  // const authRequired = !publicPages.includes(to.path);
  // const loggedIn = localStorage.getItem('users');
  // if (authRequired && !loggedIn) {
  //   return next('/login');
  // }
  next();
})

export default router