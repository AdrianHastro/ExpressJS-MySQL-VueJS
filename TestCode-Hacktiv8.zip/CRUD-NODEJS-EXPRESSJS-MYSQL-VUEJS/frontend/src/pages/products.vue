<template>
  <row>
    <column class="col-md-12">
      <form id="products" @submit.prevent="handleSubmit" method="post">
      <va-box title="Entry Data" :isBorder="true" theme="box-danger" widgetType="" :isLoading="isLoading" :isOpen="isOpen" :isMin="false" :isClosed="false">
        <div slot="content">
          <div class="form-groups col-xs-12">
            <label for="txt_name"><span>Name</span></label>
            <input type="text" id="txt_name" name="txt_name" v-model="name" placeholder="Production House Name" class="form-control" required>
          </div>
        </div>
        <div slot="footer">
          <button type="submit" class="btn btn-success">{{act==0?'Save':'Update'}}</button>
          <button type="button" class="btn btn-danger" v-show="act>0" @click="onDelete">Delete</button>
          <button type="reset" class="btn btn-info" @click="onReset()">Reset</button>
          <button type="button" class="btn pull-right" @click="onCancel()">Cancel</button>
        </div>
      </va-box>
      </form>
      <va-box title="List Data" :isBorder="true" theme="box-danger" :isLoading="isLoading2" :isOpen="isOpen2" :isRefresh="true" @refresh-click="getAllData()" @add-click="showForm()">
        <div slot="content">
          <div class="input-group">
            <div class="input-group-btn" style="width:20%">
              <select class="form-control" v-model="column">
                <option :value="null">Column Filter</option>
                <option v-show="col!='idx'&&col!='idproduct'" v-for="col in cols" :key="col">{{ col }}</option>
              </select>
            </div>     
            <input type="text" id="txt_search" v-model="search" placeholder="Search ..." class="form-control"> 
            <div class="input-group-btn"><button type="button" class="btn btn-block btn-info">Search</button></div>
            <p class="help-block" style="display: none;"></p>
          </div>
        </div>
        <div slot="footer" class="table-responsive">
          <table class="table table-striped table-hover">
            <thead>
              <tr class="sortable">
                <th v-show="col!='idx'&&col!='idproduct'" v-for="col in cols" :key="col" nowrap>{{ col }}</th>
              </tr>
            </thead>
            <tbody>
              <tr v-if="rows.length==0">
                <td :colspan="cols.length" key="0" align="center">Data Not Found!</td>
              </tr>
              <tr v-show="row!='idx'&&row!='idproduct'" v-for="row in rows" class="sortable" :key="row.id" :class="idx===row.idx?'active':''">
                <td v-show="col!='idx'&&col!='idproduct'" v-for="col in cols" :key="col">
                  <a v-if="col=='Name'" href="javascript:void(0)" title="Click here to Edit Data" @click="editMode(row)">{{ row[col] }}</a>
                  <div v-else>{{ row[col] }}</div>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </va-box>
    </column>
  </row>
</template>

<script>
import VABox from '../widgets/VABox'
import VAInputGroup from '../components/VAInputGroup'
import VACheckBox from '../components/VACheckBox'
import VAInput from '../components/VAInput'
import VAButton from '../components/VAButton'
import VATextareaGroup from '../components/VATextareaGroup'
import VAFormGroup from '../components/VAFormGroup'
import Modal from '../components/Modal'

export default {
  name: 'UserProducts',
  data:() => ({
    act: 0, isLoading: false, isOpen: false, isLoading2: false, isOpen2: true,
    error: '', message: '', 
    idx: '', name: '',
    search: null, column: null, items: [], filterby:null
  }),
  beforeMount () {
    this.getAllData()
  },
  computed: {
    cols () {
      return this.items.length >= 1 ? Object.keys(this.items[0]) : []
    },
    rows () {
      if (!this.items.length) return []
      return this.items.filter(item => {
        let props = (this.search && this.column) ? [item[this.column]] : Object.values(item)
        return props.some(prop => !this.search || ((typeof prop === 'string') ? prop.includes(this.search) : prop.toString(10).includes(this.search)))
      })
    }
  },
  methods:{
    showForm(){
      this.isOpen = !this.isOpen
      this.isOpen2 = !this.isOpen2
    },
    getAllData(){
      this.isLoading2 = true
      const msg = this.$toastr
      var data = this.$store.dispatch('getProducts',{msg})
      var dataProducts = this.$store.state.products.products
      this.items = dataProducts.map((x,i) => {
        return {
          No: i+1, idx:x.id, Name: x.name
        }
      })
      this.isLoading2 = false
    },
    clearForm(){
      this.idx=''
      this.name=''
    },
    activeForm(){
      this.isOpen=true
      this.isOpen2=false
    },
    activeTable(){
      this.isOpen=false
      this.isOpen2=true
    },
    onCancel(){
      this.act=0
      this.clearForm()
      this.activeTable()
      this.getAllData()
    },
    onReset(){
      this.act=0
      this.clearForm()
      this.activeForm()
    },
    onDelete(){
      this.$bus.$emit('modal-open', {
        title: 'Delete Confirmation',
        description: 'Are you sure?',
        type: 'modal-danger',
        confirmText: 'Yes',
        cancelText: 'No',
        confirmBefore: () => { },
        confirmAfter: () => { this.act=2, this.handleSubmit() },
        cancelBefore: () => { },
        cancelAfter: () => { },
        clickOverlay: () => { }
      })
    },
    handleSubmit(e){
      const {idx, act, name} = this
      const { dispatch, state } = this.$store
      const msg = this.$toastr
      this.isLoading = true
      if(act==0){
        let dataparam = {name}
        dispatch('ProductsAdd', {dataparam, msg})
      }else if(act==1){
        let dataparam = {idx, name}
        dispatch('ProductsEdit', {dataparam, msg})
      }else if(act==2){
        let dataparam = {idx}
        dispatch('ProductsDelete', {dataparam, msg})
      }
      let this2 = this
      setTimeout(function(){
        let newData = JSON.parse(localStorage.getItem('products'))
        this2.items = newData.map((x,i) => {
          return {
            No: i+1, idx:x.id, Name: x.name
          }
        })
        this2.isLoading = false
        if(act!=1) this2.clearForm() 
        if(act<=1){
          this2.isOpen=true
          this2.isOpen2=false
          if(act==1) this2.getAllData()
        }else{
          this2.isOpen=false
          this2.isOpen2=true
          this2.getAllData()
        }
      }, 1000)
    },
    editMode(data) {
      this.act=1
      this.activeForm()
      this.idx=data.idx
      this.name=data.Name
    }
  },
  components: {
    'va-box': VABox,
    'va-input-groups': VAInputGroup,
    'va-checkbox': VACheckBox,
    'va-input': VAInput,
    'va-button': VAButton,
    'va-textarea-groups': VATextareaGroup,
    'va-form-groups': VAFormGroup,
    'va-modal': Modal
  }
}
</script>

<style lang="css" scoped>
.modal-example .modal {
  position: relative;
  top: auto;
  bottom: auto;
  right: auto;
  left: auto;
  display: block;
  z-index: 1;
}
.modal-example .modal {
  background: transparent !important;
}
.sortable{
  cursor: pointer;
}
</style>