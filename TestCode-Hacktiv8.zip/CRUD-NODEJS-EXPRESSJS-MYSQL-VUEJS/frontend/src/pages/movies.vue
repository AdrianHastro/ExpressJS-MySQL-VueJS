<template>
  <row>
    <column class="col-md-12">
      <form id="movies" @submit.prevent="handleSubmit" method="post">
      <va-box title="Entry Data" :isBorder="true" theme="box-danger" widgetType="" :isLoading="isLoading" :isOpen="isOpen" :isMin="false" :isClosed="false">
        <div slot="content">
          <div class="col-xs-4">
            <label for="txt_movie"><span>Movies</span></label>
            <input type="text" id="txt_movie" name="txt_movie" v-model="movie" placeholder="Movies" class="form-control" required>
          </div>
          <div class="form-group col-xs-4">
            <label for="txt_genre"><span>Genre</span></label>
            <input type="text" id="txt_genre" name="txt_genre" v-model="genre" placeholder="Genre" class="form-control" required>
          </div>
          <div class="form-group col-xs-6">
            <label for="txt_idproduct"><span>Production House</span></label>
            <select class="form-control" v-model="idproduct" id="txt_idproduct" name="txt_idproduct" required>
              <option v-for="col in allproduct" :key="col.id" :value="col.id">{{ col.name }}</option>
            </select>
          </div>
        </div>
        <div slot="footer">
          <va-modal/>
          <button type="submit" class="btn btn-success">{{act==0?'Save':'Update'}}</button>
          <button type="button" class="btn btn-danger" v-show="act>0" @click="onDelete">Delete</button>
          <button type="reset" class="btn btn-info" @click="onReset()">Reset</button>
          <button type="button" class="btn pull-right" @click="onCancel()">Cancel</button>
        </div>
      </va-box>
      </form>
      <va-box title="List Data" :isBorder="true" theme="box-danger" :isLoading="isLoading2" :isOpen="isOpen2" :isRefresh="true" @refresh-click="getAllData()" @add-click="showForm()">
        <div slot="content">
          <div class="input-group">
            <div class="input-group-btn" style="width:20%">
              <select class="form-control" v-model="column">
                <option :value="null">Column Filter</option>
                <option v-show="col!='idx'&&col!='idproduct'" v-for="col in cols" :key="col">{{ col }}</option>
              </select>
            </div>     
            <input type="text" id="txt_search" v-model="search" placeholder="Search ..." class="form-control"> 
            <div class="input-group-btn"><button type="button" class="btn btn-block btn-info">Search</button></div>
            <p class="help-block" style="display: none;"></p>
          </div>
        </div>
        <div slot="footer" class="table-responsive">
          <table class="table table-striped table-hover">
            <thead>
              <tr class="sortable">
                <th v-show="col!='idx'&&col!='idproduct'" v-for="col in cols" :key="col" nowrap>{{ col }}</th>
              </tr>
            </thead>
            <tbody>
              <tr v-if="rows.length==0">
                <td :colspan="cols.length" key="0" align="center">Data Not Found!</td>
              </tr>
              <tr v-show="row!='idx'&&row!='idproduct'" v-for="row in rows" class="sortable" :key="row.id" :class="idx===row.idx?'active':''">
                <td v-show="col!='idx'&&col!='idproduct'" v-for="col in cols" :key="col">
                  <a v-if="col=='Movie'" href="javascript:void(0)" title="Click here to Edit Data" @click="editMode(row)">{{ row[col] }}</a>
                  <div v-else>{{ row[col] }}</div>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </va-box>
    </column>
  </row>
</template>

<script>
import VABox from '../widgets/VABox'
import VAInputGroup from '../components/VAInputGroup'
import VACheckBox from '../components/VACheckBox'
import VAInput from '../components/VAInput'
import VAButton from '../components/VAButton'
import VATextareaGroup from '../components/VATextareaGroup'
import VAFormGroup from '../components/VAFormGroup'
import Modal from '../components/Modal'

export default {
  name: 'ProductsManagements',
  data:() => ({
    act: 0, isLoading: false, isOpen: false, isLoading2: false, isOpen2: true,
    error: '', message: '', showpass: false,
    idx: '', movie: '', genre: '', idproduct: '', name: '', allproduct: [],
    search: null, column: null, items: [], filterby:null
  }),
  beforeMount () {
    this.getAllData()
  },
  computed: {
    cols () {
      return this.items.length >= 1 ? Object.keys(this.items[0]) : []
    },
    rows () {
      if (!this.items.length) return []
      return this.items.filter(item => {
        let props = (this.search && this.column) ? [item[this.column]] : Object.values(item)
        return props.some(prop => !this.search || ((typeof prop === 'string') ? prop.includes(this.search) : prop.toString(10).includes(this.search)))
      })
    }
  },
  methods:{
    showForm(){
      this.isOpen = !this.isOpen
      this.isOpen2 = !this.isOpen2
    },
    getAllData(){
      const msg = this.$toastr
      this.isLoading2 = true
      var dataGroup = this.$store.dispatch('getProducts',{msg})
      this.allproduct = this.$store.state.products.products
      var data = this.$store.dispatch('getMovies',{msg})
      var dataMovies = this.$store.state.movies.movies
      this.items = dataMovies.map((x,i) => {
        return {
          No: i+1, idx:x.id, Movie: x.movie, Genre: x.genre, idproduct:x.idproduct, 'Production House': x.name
        }
      })
      this.isLoading2 = false
    },
    clearForm(){
      this.idx=''
      this.movie=''
      this.genre=''
      this.idgroup=''
      this.name=''
    },
    activeForm(){
      this.isOpen=true
      this.isOpen2=false
    },
    activeTable(){
      this.isOpen=false
      this.isOpen2=true
    },
    onCancel(){
      this.act=0
      this.clearForm()
      this.activeTable()
      this.getAllData()
    },
    onReset(){
      this.act=0
      this.clearForm()
      this.activeForm()
    },
    showpassword(){
      this.showpass = !this.showpass
    },
    onDelete(){
      this.$bus.$emit('modal-open', {
        title: 'Delete Confirmation',
        description: 'Are you sure?',
        type: 'modal-danger',
        confirmText: 'Yes',
        cancelText: 'No',
        confirmBefore: () => { },
        confirmAfter: () => { this.act=2, this.handleSubmit() },
        cancelBefore: () => { },
        cancelAfter: () => { },
        clickOverlay: () => { }
      })
    },
    handleSubmit(e){
      const {idx, act, movie, genre, idproduct, name, allproduct} = this
      const { dispatch, state } = this.$store
      const msg = this.$toastr
      this.isLoading = true
      let fname = allproduct.filter(x=>x.id==idproduct)
      this.name = fname.length ? fname[0].name : '';
      if(act==0){
        let dataparam = {movie, genre, idproduct, name}
        dispatch('MoviesAdd', {dataparam, msg})
      }else if(act==1){
        let dataparam = {idx, movie, genre, idproduct, name}
        dispatch('MoviesEdit', {dataparam, msg})
      }else if(act==2){
        let dataparam = {idx}
        dispatch('MoviesDelete', {dataparam, msg})
      }
      let this2 = this
      setTimeout(function(){
        let newData = JSON.parse(localStorage.getItem('movies'))
        this2.items = newData.map((x,i) => {
          return {
            No: i+1, idx:x.id, Movie: x.movie, Genre: x.genre, idproduct:x.idproduct, 'Production House': x.name
          }
        })
        this2.isLoading = false
        if(act!=1) this2.clearForm() 
        if(act<=1){
          this2.isOpen=true
          this2.isOpen2=false
          if(act==1) this2.getAllData()
        }else{
          this2.isOpen=false
          this2.isOpen2=true
          this2.getAllData()
        }
      }, 1000)
    },
    async editMode(data) {
      this.act=1
      this.activeForm()
      this.idx=data.idx
      this.movie=data.Movie
      this.password=data.Password
      this.genre=data.Genre
      this.idproduct=data.idproduct
      this.name=data['Production House']
    }
  },
  components: {
    'va-box': VABox,
    'va-input-group': VAInputGroup,
    'va-checkbox': VACheckBox,
    'va-input': VAInput,
    'va-button': VAButton,
    'va-textarea-group': VATextareaGroup,
    'va-form-group': VAFormGroup,
    'va-modal': Modal
  }
}
</script>

<style lang="css" scoped>
.modal-example .modal {
  position: relative;
  top: auto;
  bottom: auto;
  right: auto;
  left: auto;
  display: block;
  z-index: 1;
}
.modal-example .modal {
  background: transparent !important;
}
.sortable{
  cursor: pointer;
}
</style>