<template>
  <div>
    Modals Page
  </div>
</template>

<script>
export default {
  name: 'Modals',
  created () {

  }
}
</script>
