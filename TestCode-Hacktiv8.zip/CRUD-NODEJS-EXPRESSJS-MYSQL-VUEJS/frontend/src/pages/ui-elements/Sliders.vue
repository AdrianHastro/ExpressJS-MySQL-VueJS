<template>
  <div>
    Sliders Page
  </div>
</template>

<script>
export default {
  name: 'Sliders',
  created () {

  }
}
</script>
