<template>

  <div v-if="isHorizontal" class="form-group">
    <div class="col-sm-offset-2 col-sm-10">
      <div class="checkbox">
        <label>
          <input type="checkbox" :id="vaId" :checked="isChecked" />{{ text }}
        </label>
      </div>
    </div>
  </div>
  <div v-else class="checkbox">
    <label>
      <input type="checkbox" :id="vaId" :disabled="isDisabled" :checked="isChecked"/>{{ text }}
    </label>
  </div>
</template>

<script>
export default {
  name: 'va-checkbox',
  props: {
    vaId: {
      type: String
    },
    text: {
      type: String,
      default: 'Check me out'
    },
    isHorizontal: {
      type: Boolean,
      default: false
    },
    isDisabled: {
      type: Boolean,
      default: false
    },
    isChecked: {
      type: Boolean,
      default: true
    }
  },
  created () {

  }
}
</script>
