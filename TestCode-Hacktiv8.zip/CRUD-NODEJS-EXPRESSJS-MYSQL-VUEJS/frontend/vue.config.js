const webpack = require('webpack');

module.exports = {
  publicPath: '/frontend-hacktiv8/',
  pluginOptions: {
    webpackBundleAnalyzer: {
      openAnalyzer: false,
    },
  },
  configureWebpack: {
    plugins: [
      new webpack.ContextReplacementPlugin(/moment[/\\]locale$/, /en|id/),
    ],
  },
  transpileDependencies: ['vue-echarts', 'resize-detector'],
};
